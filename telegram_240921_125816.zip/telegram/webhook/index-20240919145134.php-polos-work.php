<?php
// Token bot Anda
$bot_token = '7530717438:AAFDpkb15BzqvjJx8-jNDT-Kg6JS0uhgbuo';
$api_url = "https://api.telegram.org/bot$bot_token";

// Mendapatkan update dari Telegram
$content = file_get_contents("php://input");
$update = json_decode($content, true);

// Menulis update ke log untuk debugging
file_put_contents('/www/raddash/telegram/log.txt', "Update received: " . print_r($update, true) . "\n", FILE_APPEND);

// Memeriksa jenis update
if (isset($update['message'])) {
    $chat_id = $update['message']['chat']['id'];
    $message = $update['message']['text'];

    // Tangani perintah yang diterima
    if (strpos($message, "/start") === 0) {
        $reply = "Haloo, test webhooks dicoffeean.com.";
    } elseif (strpos($message, "/profile") === 0) {
        $reply = "Ini adalah profil Anda.";
    } else {
        $reply = "Anda mengirim: " . $message;
    }

    // Kirim balasan
    $send_response = file_get_contents($api_url . "/sendMessage?chat_id=$chat_id&text=" . urlencode($reply));

    // Tulis respons API Telegram ke log untuk debugging
    file_put_contents('/www/raddash/telegram/log.txt', "SendMessage response: " . $send_response . "\n", FILE_APPEND);
}
?>
