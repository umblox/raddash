<?php
// Muat konfigurasi dari file config.php
require_once '/www/raddash/telegram/webhook/config.php';

// Koneksi ke database
$connection = new mysqli(DB_CONFIG['host'], DB_CONFIG['user'], DB_CONFIG['password'], DB_CONFIG['database']);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// URL webhook Anda
$webhook_url = 'https://arneta.my.id/raddash/telegram/webhook/webhook.php';

// Ganti dengan token bot Anda dari konfigurasi
$bot_token = BOT_TOKEN;

// Mengatur webhook
$api_url = "https://api.telegram.org/bot$bot_token/setWebhook?url=$webhook_url";
$response = file_get_contents($api_url);
if ($response) {
    echo "Webhook telah diatur.";
} else {
    echo "Gagal mengatur webhook.";
}

// Mendapatkan update dari Telegram
$content = file_get_contents("php://input");
$update = json_decode($content, true);

// Menulis update ke log untuk debugging
file_put_contents('/www/raddash/telegram/webhook/log.txt', print_r($update, true), FILE_APPEND);

// Memeriksa jenis update
if (isset($update['message'])) {
    $chat_id = $update['message']['chat']['id'];
    $message = $update['message']['text'];
    $username = isset($update['message']['from']['username']) ? $update['message']['from']['username'] : '';

    // Fungsi untuk menangani perintah /start
    if (isset($update['message']['text']) && trim($update['message']['text']) === '/start') {
        if (!$username) {
            sendMessage($chat_id, "Anda harus memasang username di Telegram terlebih dahulu untuk menggunakan bot ini. "
            . "Silakan pasang username di pengaturan Telegram, kemudian coba lagi dengan perintah /start.");
        } else {
            handleStartCommand($chat_id, $username);
        }
    } elseif (trim($message) === '/saldo') {
        handleSaldoCommand($chat_id, $username);
    } elseif (trim($message) === '/beli') {
        handleBeliCommand($chat_id);
    } elseif (trim($message) === '/topup') {
        handleTopupCommand($chat_id, $username);
    }

} elseif (isset($update['callback_query'])) {
    handleCallbackQuery($update['callback_query']);
}

// Fungsi untuk mengirim pesan menggunakan API Telegram
function sendMessage($chat_id, $message, $reply_markup = null) {
    global $bot_token;
    $url = "https://api.telegram.org/bot$bot_token/sendMessage";
    $data = array('chat_id' => $chat_id, 'text' => $message);
    
    if ($reply_markup) {
        $data['reply_markup'] = json_encode($reply_markup);
    }
    
    $options = array(
        'http' => array(
            'header'  => "Content-Type: application/x-www-form-urlencoded\r\n",
            'method'  => 'POST',
            'content' => http_build_query($data),
        ),
    );
    $context  = stream_context_create($options);
    return file_get_contents($url, false, $context);
}

// Fungsi untuk menangani perintah /start
function handleStartCommand($user_id, $username) {
    global $connection;

    // Cek apakah pengguna sudah ada di database
    $stmt = $connection->prepare("SELECT id FROM users WHERE telegram_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $existing_user = $result->fetch_assoc();

    if (!$existing_user) {
        // Jika pengguna baru, masukkan ke dalam database
        $stmt = $connection->prepare(
            "INSERT INTO users (telegram_id, username, password, balance) VALUES (?, ?, ?, ?)"
        );
        $password = ''; // Kosongkan password
        $balance = 0; // Saldo awal 0
        $stmt->bind_param("issi", $user_id, $username, $password, $balance);
        $stmt->execute();
    }

    // Sambutan untuk pengguna baru dan daftar perintah
    $welcome_message = 
        "Selamat datang di bot billing arneta.id!\n\n"
        . "Berikut rincian akun Anda:\n"
        . "ID Pengguna: $user_id\n"
        . "Username: @$username\n\n"
        . "Daftar perintah yang tersedia:\n"
        . "/profile - Untuk melihat profile anda\n"
        . "/topup - Untuk isi ulang saldo\n"
        . "/beli - Untuk membeli voucher\n"
        . "/saldo - Untuk mengecek saldo Anda";
    sendMessage($user_id, $welcome_message);
}

// Fungsi untuk menangani perintah /saldo
function handleSaldoCommand($chat_id, $username) {
    global $connection;
    
    // Ambil saldo user dari database
    $stmt = $connection->prepare("SELECT balance FROM users WHERE telegram_id = ?");
    $stmt->bind_param("i", $chat_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    
    if ($user) {
        $saldo = $user['balance'];
        sendMessage($chat_id, "Saldo Anda saat ini: Rp " . number_format($saldo));
    } else {
        sendMessage($chat_id, "Akun Anda tidak ditemukan.");
    }
}

// Fungsi untuk menangani perintah /beli
function handleBeliCommand($chat_id) {
    global $connection;

    // Ambil paket yang tersedia dari database billing_plans
    $stmt = $connection->prepare("SELECT id, plan_name, price FROM billing_plans WHERE price > 0");
    $stmt->execute();
    $result = $stmt->get_result();

    $keyboard = [];
    while ($plan = $result->fetch_assoc()) {
        $keyboard[] = [
            ['text' => $plan['plan_name'] . ' - Rp ' . number_format($plan['price']), 'callback_data' => 'beli_paket_' . $plan['id']]
        ];
    }

    $reply_markup = array('inline_keyboard' => $keyboard);
    sendMessage($chat_id, "Pilih paket yang ingin Anda beli:", $reply_markup);
}

// Fungsi untuk menangani perintah /topup
function handleTopupCommand($chat_id, $username) {
    global $connection;

    // Cek apakah user memiliki topup pending
    $stmt = $connection->prepare("SELECT id FROM topup_requests WHERE telegram_id = ? AND status = 'pending'");
    $stmt->bind_param("i", $chat_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $pending_request = $result->fetch_assoc();

    if ($pending_request) {
        sendMessage($chat_id, "Anda memiliki permintaan top-up yang sedang menunggu konfirmasi.");
        return;
    }

    // Tampilkan opsi nominal topup
    $keyboard = [
        [['text' => 'Rp 3.000', 'callback_data' => 'topup_3000']],
        [['text' => 'Rp 5.000', 'callback_data' => 'topup_5000']],
        [['text' => 'Rp 10.000', 'callback_data' => 'topup_10000']],
        [['text' => 'Rp 20.000', 'callback_data' => 'topup_20000']],
        [['text' => 'Rp 50.000', 'callback_data' => 'topup_50000']],
        [['text' => 'Rp 100.000', 'callback_data' => 'topup_100000']],
    ];

    $reply_markup = array('inline_keyboard' => $keyboard);
    sendMessage($chat_id, "Pilih nominal top-up:", $reply_markup);
}

// Fungsi untuk menangani callback query
function handleCallbackQuery($callback_query) {
    global $connection;

    $callback_data = $callback_query['data'];
    $chat_id = $callback_query['message']['chat']['id'];
    $message_id = $callback_query['message']['message_id'];

    // Tangani callback untuk top-up
    if (strpos($callback_data, 'topup_') === 0) {
        // Ambil nominal topup
        $amount = str_replace('topup_', '', $callback_data);

        // Konfirmasi nominal
        $keyboard = array(
            array(
                array('text' => 'Benar', 'callback_data' => 'confirm_topup_' . $amount),
                array('text' => 'Salah', 'callback_data' => 'cancel_topup')
            )
        );

        $reply_markup = array(
            'inline_keyboard' => $keyboard
        );

        sendMessage($chat_id, "Apakah Anda yakin ingin melakukan top-up sebesar Rp " . number_format($amount) . "?", $reply_markup);

    // Tangani callback untuk konfirmasi top-up
    } elseif (strpos($callback_data, 'confirm_topup_') === 0) {
        $amount = str_replace('confirm_topup_', '', $callback_data);

        // Masukkan permintaan top-up ke database
        $stmt = $connection->prepare("INSERT INTO topup_requests (telegram_id, amount, status) VALUES (?, ?, 'pending')");
        $stmt->bind_param("ii", $chat_id, $amount);
        $stmt->execute();

        sendMessage($chat_id, "Permintaan top-up sebesar Rp " . number_format($amount) . " telah diterima. Silakan tunggu konfirmasi dari admin.");
    
    // Tangani callback untuk pembatalan top-up
    } elseif ($callback_data === 'cancel_topup') {
        sendMessage($chat_id, "Permintaan top-up dibatalkan.");
    }

    // Tangani callback untuk pembelian paket
    if (strpos($callback_data, 'beli_paket_') === 0) {
        $plan_id = str_replace('beli_paket_', '', $callback_data);

        // Ambil paket dari database
        $stmt = $connection->prepare("SELECT plan_name, price FROM billing_plans WHERE id = ?");
        $stmt->bind_param("i", $plan_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $plan = $result->fetch_assoc();

        if ($plan) {
            sendMessage($chat_id, "Anda memilih paket: " . $plan['plan_name'] . " dengan harga Rp " . number_format($plan['price']));
            // Lakukan logika pembelian, misalnya pengurangan saldo dan pemberian voucher
        } else {
            sendMessage($chat_id, "Paket yang dipilih tidak ditemukan.");
        }
    }
}
