<?php
// Token bot Anda
$bot_token = '7530717438:AAFDpkb15BzqvjJx8-jNDT-Kg6JS0uhgbuo';
$api_url = "https://api.telegram.org/bot$bot_token";

// Mendapatkan update dari Telegram
$content = file_get_contents("php://input");
$update = json_decode($content, true);

// Menulis update ke log untuk debugging
file_put_contents('/www/raddash/telegram/log.txt', "Update received: " . print_r($update, true) . "\n", FILE_APPEND);

// Memeriksa jenis update
if (isset($update['message'])) {
    $chat_id = $update['message']['chat']['id'];
    $user_id = $update['message']['from']['id'];
    $message = $update['message']['text'];

    // Tangani perintah yang diterima
    switch (true) {
        case strpos($message, "/start") === 0:
            require_once '/www/raddash/telegram/commands/startController.php';
            handleStart($chat_id, $user_id);
            break;

        case strpos($message, "/saldo") === 0:
            require_once '/www/raddash/telegram/commands/saldoController.php';
            handleSaldo($chat_id, $user_id);
            break;

        case strpos($message, "/topup") === 0:
            require_once '/www/raddash/telegram/commands/topupController.php';
            handleTopup($chat_id, $user_id);
            break;

        case strpos($message, "/beli") === 0:
            require_once '/www/raddash/telegram/commands/beliController.php';
            handleBeli($chat_id, $user_id);
            break;

        case strpos($message, "/profile") === 0:
            require_once '/www/raddash/telegram/commands/profileController.php';
            handleProfile($chat_id, $user_id);
            break;

        default:
            require_once '/www/raddash/telegram/commands/unknownController.php';
            handleUnknown($chat_id, $message);
            break;
    }
}

function sendMessage($chat_id, $text) {
    global $api_url;
    $url = $api_url . "/sendMessage";
    $data = [
        'chat_id' => $chat_id,
        'text' => $text,
    ];
    $options = [
        'http' => [
            'header'  => "Content-Type: application/x-www-form-urlencoded\r\n",
            'method'  => 'POST',
            'content' => http_build_query($data),
        ],
    ];
    $context  = stream_context_create($options);
    $send_response = file_get_contents($url, false, $context);

    // Tulis respons API Telegram ke log untuk debugging
    file_put_contents('/www/raddash/telegram/log.txt', "SendMessage response: " . $send_response . "\n", FILE_APPEND);
}
?>
