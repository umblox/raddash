<?php
// Muat konfigurasi dari file config.php
require_once '/www/raddash/telegram/webhook/config.php';

// Koneksi ke database
$connection = new mysqli(DB_CONFIG['host'], DB_CONFIG['user'], DB_CONFIG['password'], DB_CONFIG['database']);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// URL webhook Anda
$webhook_url = 'https://arneta.my.id/raddash/telegram/webhook/webhook.php';

// Ganti dengan token bot Anda dari konfigurasi
$bot_token = BOT_TOKEN;

// Mengatur webhook
$api_url = "https://api.telegram.org/bot$bot_token/setWebhook?url=$webhook_url";
$response = file_get_contents($api_url);
if ($response) {
    echo "Webhook telah diatur.";
} else {
    echo "Gagal mengatur webhook.";
}

// Mendapatkan update dari Telegram
$content = file_get_contents("php://input");
$update = json_decode($content, true);

// Menulis update ke log untuk debugging
file_put_contents('/www/raddash/telegram/webhook/log.txt', print_r($update, true), FILE_APPEND);

// Memeriksa jenis update
if (isset($update['message'])) {
    $chat_id = $update['message']['chat']['id'];
    $message = $update['message']['text'];
    $username = isset($update['message']['from']['username']) ? $update['message']['from']['username'] : '';

    // Fungsi untuk menangani perintah /start
if (isset($update['message']['text']) && trim($update['message']['text']) === '/start') {
    if (!$username) {
        sendMessage($chat_id, "Anda harus memasang username di Telegram terlebih dahulu untuk menggunakan bot ini. "
        . "Silakan pasang username di pengaturan Telegram, kemudian coba lagi dengan perintah /start.");
    } else {
        handleStartCommand($chat_id, $username);
    }
}
    // Tulis respons API Telegram ke log untuk debugging
    file_put_contents('/www/raddash/telegram/webhook/log.txt', "Send message response: " . $send_response . "\n", FILE_APPEND);
}

// Fungsi untuk mengirim pesan menggunakan API Telegram
function sendMessage($chat_id, $message) {
    global $bot_token;
    $url = "https://api.telegram.org/bot$bot_token/sendMessage";
    $data = array('chat_id' => $chat_id, 'text' => $message);
    $options = array(
        'http' => array(
            'header'  => "Content-Type: application/x-www-form-urlencoded\r\n",
            'method'  => 'POST',
            'content' => http_build_query($data),
        ),
    );
    $context  = stream_context_create($options);
    return file_get_contents($url, false, $context);
}

// Fungsi untuk menangani perintah /start
function handleStartCommand($user_id, $username) {
    global $connection;

    file_put_contents('/www/raddash/telegram/webhook/log.txt', "Executing handleStartCommand for user_id: $user_id, username: $username\n", FILE_APPEND);

    // Cek apakah pengguna sudah ada di database
    $stmt = $connection->prepare("SELECT id FROM users WHERE telegram_id = ?");
    if (!$stmt) {
        file_put_contents('/www/raddash/telegram/webhook/log.txt', "Prepare statement failed: " . $connection->error . "\n", FILE_APPEND);
    }
    
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $existing_user = $result->fetch_assoc();

    if (!$existing_user) {
        // Jika pengguna baru, masukkan ke dalam database
        file_put_contents('/www/raddash/telegram/webhook/log.txt', "Inserting new user: $user_id, $username\n", FILE_APPEND);
        
        $stmt = $connection->prepare(
            "INSERT INTO users (telegram_id, username, password, balance) VALUES (?, ?, ?, ?)"
        );
        if (!$stmt) {
            file_put_contents('/www/raddash/telegram/log.txt', "Insert statement failed: " . $connection->error . "\n", FILE_APPEND);
        }
        $password = ''; // Kosongkan password
        $balance = 0; // Saldo awal 0
        $stmt->bind_param("issi", $user_id, $username, $password, $balance);
        $stmt->execute();
    }

    // Sambutan untuk pengguna baru dan daftar perintah
    $welcome_message = 
        "Selamat datang di bot billing arneta.id!\n\n"
        . "Berikut rincian akun Anda:\n"
        . "ID Pengguna: $user_id\n"
        . "Username: @$username\n\n"
        . "Daftar perintah yang tersedia:\n"
        . "/profile - Untuk melihat profile anda\n"
        . "/topup - Untuk isi ulang saldo\n"
        . "/beli - Untuk membeli voucher\n"
        . "/saldo - Untuk mengecek saldo Anda";
    sendMessage($user_id, $welcome_message);

    $stmt->close();
}

// Tutup koneksi database saat skrip selesai dieksekusi
register_shutdown_function(function () use ($connection) {
    $connection->close();
});
?>
