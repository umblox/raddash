<?php
$bot_token = '7530717438:AAFDpkb15BzqvjJx8-jNDT-Kg6JS0uhgbuo';
$api_url = "https://api.telegram.org/bot$bot_token/getWebhookInfo";
$response = file_get_contents($api_url);
echo "Webhook info: " . $response;
?>
