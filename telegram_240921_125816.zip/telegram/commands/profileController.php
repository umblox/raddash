<?php
// profile.php

// Konfigurasi Database dan Telegram Bot
$host = '127.0.0.1';
$dbname = 'radius';
$user = 'radius';
$pass = 'radius';
$adminId = '2123457759';
$botToken = '7530717438:AAFDpkb15BzqvjJx8-jNDT-Kg6JS0uhgbuo';

// Koneksi Database
$mysqli = new mysqli($host, $user, $pass, $dbname);
if ($mysqli->connect_error) {
    error_log("Koneksi database gagal: " . $mysqli->connect_error);
    exit;
}

// Kelas untuk Telegram Bot
class profileController {
    private $token;

    public function __construct($token) {
        $this->token = $token;
    }

    private function request($method, $data) {
        $url = "https://api.telegram.org/bot{$this->token}/{$method}";
        $options = [
            'http' => [
                'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
                'method'  => 'POST',
                'content' => http_build_query($data),
            ],
        ];
        $context  = stream_context_create($options);
        return file_get_contents($url, false, $context);
    }

    public function sendMessage($chat_id, $text, $reply_markup = null) {
        $data = ['chat_id' => $chat_id, 'text' => $text];
        if ($reply_markup) {
            $data['reply_markup'] = json_encode($reply_markup);
        }
        return $this->request('sendMessage', $data);
    }

    public function editMessageText($chat_id, $message_id, $text, $reply_markup = null) {
        $data = [
            'chat_id' => $chat_id,
            'message_id' => $message_id,
            'text' => $text
        ];
        if ($reply_markup) {
            $data['reply_markup'] = json_encode($reply_markup);
        }
        return $this->request('editMessageText', $data);
    }

    public function deleteMessage($chat_id, $message_id) {
        $data = ['chat_id' => $chat_id, 'message_id' => $message_id];
        return $this->request('deleteMessage', $data);
    }
}

$bot = new TelegramBot($botToken);

// Mengambil data dari Telegram
$update = json_decode(file_get_contents('php://input'), true);

if (isset($update['message']) || isset($update['callback_query'])) {
    $chat_id = $update['message']['chat']['id'] ?? $update['callback_query']['message']['chat']['id'];
    $message_id = $update['message']['message_id'] ?? $update['callback_query']['message']['message_id'];
    $user_id = $update['message']['from']['id'] ?? $update['callback_query']['from']['id'];
    $text = $update['message']['text'] ?? $update['callback_query']['data'];

    if (isset($update['message'])) {
        // Handle /profile command
        if ($text === '/profile') {
            $stmt = $mysqli->prepare("SELECT * FROM users WHERE telegram_id=?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $user = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if ($user) {
                $profile_message = "Profil Anda:\n\n";
                $profile_message .= "Telegram ID: {$user['telegram_id']}\n";
                $profile_message .= "Username: @{$user['username']}\n";
                $profile_message .= "Saldo: {$user['balance']} kredit\n";
                $profile_message .= "Anda hanya boleh mengganti username jika Anda benar-benar telah mengganti username Telegram Anda, atau saldo Anda bisa hilang.\n\n";
                $profile_message .= "Masukkan username sesuai username baru Telegram Anda.\n";

                // Membuat tombol untuk ubah username dan password
                $keyboard = [
                    'inline_keyboard' => [
                        [['text' => 'Ubah Username', 'callback_data' => 'change_username']],
                        [['text' => 'Lihat Password', 'callback_data' => 'show_password']],
                        [['text' => 'Ubah Password', 'callback_data' => 'change_password']]
                    ]
                ];
                $bot->sendMessage($chat_id, $profile_message, $keyboard);
            } else {
                $bot->sendMessage($chat_id, "Data Anda tidak ditemukan.");
            }
        }
    }

    if (isset($update['callback_query'])) {
        $query = $update['callback_query'];
        $callback_data = $query['data'];
        $user_id = $query['from']['id'];
        $message_id = $query['message']['message_id'];

        if ($callback_data === 'change_username') {
            $bot->editMessageText($chat_id, $message_id, "Masukkan username baru yang Anda inginkan:");
            // Set flag untuk menunggu input username
            $_SESSION['waiting_for_username'] = true;

        } elseif ($callback_data === 'show_password') {
            $stmt = $mysqli->prepare("SELECT password FROM users WHERE telegram_id=?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if ($result) {
                $password = $result['password'];
                $keyboard = [
                    'inline_keyboard' => [
                        [['text' => 'Tutup', 'callback_data' => 'close_message']]
                    ]
                ];
                $bot->editMessageText($chat_id, $message_id, "Password Anda adalah: $password", $keyboard);
            } else {
                $bot->editMessageText($chat_id, $message_id, "Password tidak ditemukan.");
            }

        } elseif ($callback_data === 'change_password') {
            $bot->editMessageText($chat_id, $message_id, "Masukkan password baru yang Anda inginkan:");
            // Set flag untuk menunggu input password
            $_SESSION['waiting_for_password'] = true;

        } elseif ($callback_data === 'confirm_username_change' || $callback_data === 'cancel_username_change') {
            if ($callback_data === 'confirm_username_change' && isset($_SESSION['new_username'])) {
                $new_username = $_SESSION['new_username'];
                $stmt = $mysqli->prepare("UPDATE users SET username=? WHERE telegram_id=?");
                $stmt->bind_param("si", $new_username, $user_id);
                $stmt->execute();
                $stmt->close();

                $bot->editMessageText($chat_id, $message_id, "Username Anda telah diubah menjadi @$new_username.");
                unset($_SESSION['new_username']);
                unset($_SESSION['waiting_for_username']);

            } elseif ($callback_data === 'cancel_username_change') {
                $bot->editMessageText($chat_id, $message_id, "Perubahan username dibatalkan.");
                unset($_SESSION['waiting_for_username']);
                unset($_SESSION['new_username']);
            }

        } elseif ($callback_data === 'confirm_password_change' || $callback_data === 'cancel_password_change') {
            if ($callback_data === 'confirm_password_change' && isset($_SESSION['new_password'])) {
                $new_password = $_SESSION['new_password'];
                $stmt = $mysqli->prepare("UPDATE users SET password=? WHERE telegram_id=?");
                $stmt->bind_param("si", $new_password, $user_id);
                $stmt->execute();
                $stmt->close();

                $bot->editMessageText($chat_id, $message_id, "Password Anda berhasil diubah.");
                unset($_SESSION['new_password']);
                unset($_SESSION['waiting_for_password']);

            } elseif ($callback_data === 'cancel_password_change') {
                $bot->editMessageText($chat_id, $message_id, "Perubahan password dibatalkan.");
                unset($_SESSION['waiting_for_password']);
                unset($_SESSION['new_password']);
            }

        } elseif ($callback_data === 'close_message') {
            $bot->deleteMessage($chat_id, $message_id);
        }
    }

    // Menangani input dari pengguna untuk mengubah username atau password
    if (isset($_SESSION['waiting_for_username']) && !empty($text)) {
        $_SESSION['new_username'] = $text;
        $keyboard = [
            'inline_keyboard' => [
                [['text' => 'Ya', 'callback_data' => 'confirm_username_change']],
                [['text' => 'Batal', 'callback_data' => 'cancel_username_change']]
            ]
        ];
        $bot->sendMessage($chat_id, "Username baru Anda adalah: $text. Apakah Anda ingin mengonfirmasi?", $keyboard);
        unset($_SESSION['waiting_for_username']);

    } elseif (isset($_SESSION['waiting_for_password']) && !empty($text)) {
        $_SESSION['new_password'] = $text;
        $keyboard = [
            'inline_keyboard' => [
                [['text' => 'Ya', 'callback_data' => 'confirm_password_change']],
                [['text' => 'Batal', 'callback_data' => 'cancel_password_change']]
            ]
        ];
        $bot->sendMessage($chat_id, "Apakah Anda yakin ingin mengganti password menjadi $text?", $keyboard);
        unset($_SESSION['waiting_for_password']);
    } elseif (!isset($_SESSION['waiting_for_username']) && !isset($_SESSION['waiting_for_password'])) {
        $bot->sendMessage($chat_id, "Perintah tidak dikenali.");
    }
}
?>
