<?php
require '/www/raddash/vendor/autoload.php'; // Memuat autoload dari Composer
require 'config.php';  // Memuat konfigurasi

use Telegram\Bot\Api;

$telegram = new Api(BOT_TOKEN); // Inisialisasi API Telegram

function handleStartCommand($chatId, $username, $telegram) {
    // Cek apakah username tidak kosong
    if (empty($username)) {
        return "Anda harus memasang username di Telegram terlebih dahulu untuk menggunakan bot ini.";
    }

    $conn = getDbConnection();

    // Cek jika pengguna sudah ada
    $stmt = $conn->prepare("SELECT id FROM users WHERE telegram_id = ?");
    $stmt->bind_param("i", $chatId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Pengguna sudah terdaftar
        return "Anda sudah terdaftar!\n\nBerikut adalah daftar perintah yang tersedia:\n/topup - Untuk isi ulang saldo\n/beli - Untuk membeli voucher\n/saldo - Untuk mengecek saldo Anda\n/profile - Untuk melihat profile anda\n/status - Untuk melihat status voucher Anda.";
    } else {
        // Pengguna baru, masukkan ke dalam database
        $stmt = $conn->prepare("INSERT INTO users (telegram_id, username, password, balance) VALUES (?, ?, '', 0)");
        $stmt->bind_param("is", $chatId, $username);
        if ($stmt->execute()) {
            // Kirim pesan sambutan
            return "Selamat datang di bot billing arneta.id!\n\nBerikut rincian akun Anda:\nID Pengguna: $chatId\nUsername: @$username\n\nDaftar perintah yang tersedia:\n/topup - Untuk isi ulang saldo\n/beli - Untuk membeli voucher\n/saldo - Untuk mengecek saldo Anda\n/profile - Untuk melihat profile anda\n/status - Untuk melihat status voucher Anda.";
        } else {
            return "Terjadi kesalahan saat mendaftar pengguna baru.";
        }
    }
}

// Fungsi untuk memanggil command dari Telegram
function processStartCommand($update, $telegram) {
    $chatId = $update['message']['chat']['id'];
    $username = $update['message']['from']['username'] ?? '';

    $responseMessage = handleStartCommand($chatId, $username, $telegram);
    sendMessage($chatId, $responseMessage, $telegram);
}

// Fungsi untuk mengirim pesan ke pengguna menggunakan library TelegramBotPHP
function sendMessage($chatId, $text, $telegram) {
    $telegram->sendMessage([
        'chat_id' => $chatId,
        'text' => $text,
        'parse_mode' => 'Markdown' // Menggunakan Markdown untuk formatting
    ]);
}

// Pengolahan update dari Telegram
$update = json_decode(file_get_contents('php://input'), true);
if (isset($update['message']['text']) && $update['message']['text'] === '/start') {
    processStartCommand($update, $telegram);
}
?>
