// Fungsi untuk membuat kode voucher
function generate_voucher_code($planName) {
    global $VOUCHER_PREFIX;
    $prefix = isset($VOUCHER_PREFIX[$planName]) ? $VOUCHER_PREFIX[$planName] : '';
    $random_part = substr(str_shuffle("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"), 0, 5);
    return $prefix . $random_part;
}

// Fungsi untuk menampilkan paket yang tersedia
function handleBeli($chat_id, $user_id, $bot_token) {
    $conn = get_db_connection();
    $sql = "SELECT id, planName, planCost FROM billing_plans WHERE planCost > 0";
    $result = $conn->query($sql);

    if ($result->num_rows === 0) {
        sendMessage($chat_id, "Tidak ada paket yang tersedia untuk dibeli.", $bot_token);
        $conn->close();
        return;
    }

    $keyboard = [];
    while ($row = $result->fetch_assoc()) {
        $keyboard[] = [['text' => $row['planName'] . ' - ' . $row['planCost'], 'callback_data' => 'confirm_beli_' . $row['id']]];
    }

    $reply_markup = json_encode(['inline_keyboard' => $keyboard]);
    sendMessage($chat_id, "Pilih paket yang ingin Anda beli:", $bot_token, $reply_markup);

    $conn->close();
}

// Fungsi untuk mengirim pesan ke pengguna
function sendMessage($chat_id, $text, $bot_token, $reply_markup = null) {
    $url = "https://api.telegram.org/bot$bot_token/sendMessage";
    $post_fields = [
        'chat_id' => $chat_id,
        'text' => $text,
        'reply_markup' => $reply_markup
    ];

    $ch = curl_init(); 
    curl_setopt($ch, CURLOPT_HTTPHEADER, ["Content-Type:multipart/form-data"]);
    curl_setopt($ch, CURLOPT_URL, $url); 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_fields); 
    curl_exec($ch);
    curl_close($ch); 
}

// Fungsi untuk menangani callback dari pengguna saat memilih paket
function beli_confirm_callback($callback_query, $bot_token) {
    $callback_data = explode('_', $callback_query['data']);
    $plan_id = $callback_data[2];
    $chat_id = $callback_query['message']['chat']['id'];
    $user_id = $callback_query['from']['id'];
    $telegram_username = $callback_query['from']['username'];

    $conn = get_db_connection();
    $sql = "SELECT planName, planCost FROM billing_plans WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $plan_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $plan = $result->fetch_assoc();

    if (!$plan) {
        sendMessage($chat_id, "Paket tidak ditemukan.", $bot_token);
        $stmt->close();
        $conn->close();
        return;
    }

    // Tampilkan konfirmasi pembelian
    $confirmation_message = "Anda telah memilih paket: {$plan['planName']} dengan harga {$plan['planCost']}\n\nApakah Anda ingin melanjutkan pembelian?";
    $keyboard = [
        [['text' => "Ya", 'callback_data' => 'beli_' . $plan_id], ['text' => "Batal", 'callback_data' => "cancel_beli"]]
    ];
    $reply_markup = json_encode(['inline_keyboard' => $keyboard]);
    sendMessage($chat_id, $confirmation_message, $bot_token, $reply_markup);

    $stmt->close();
    $conn->close();
}

// Fungsi untuk memproses pembelian voucher setelah konfirmasi
function beli_callback($callback_query, $bot_token) {
    $callback_data = explode('_', $callback_query['data']);
    $plan_id = $callback_data[1];
    $chat_id = $callback_query['message']['chat']['id'];
    $user_id = $callback_query['from']['id'];
    $telegram_username = $callback_query['from']['username'];

    $conn = get_db_connection();

    // Dapatkan data paket
    $sql = "SELECT planName, planCost FROM billing_plans WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $plan_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $plan = $result->fetch_assoc();

    if (!$plan) {
        sendMessage($chat_id, "Paket tidak ditemukan.", $bot_token);
        $stmt->close();
        $conn->close();
        return;
    }

    // Periksa saldo pengguna
    $sql = "SELECT balance FROM users WHERE telegram_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if (!$user || $user['balance'] < $plan['planCost']) {
        sendMessage($chat_id, "Saldo Anda tidak mencukupi. Saldo saat ini: " . $user['balance'], $bot_token);
        $stmt->close();
        $conn->close();
        return;
    }

    // Lanjutkan pembelian dan kurangi saldo
    $new_balance = $user['balance'] - $plan['planCost'];
    $sql = "UPDATE users SET balance = ? WHERE telegram_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("di", $new_balance, $user_id);
    $stmt->execute();

    // Buat voucher
    $voucher_code = generate_voucher_code($plan['planName']);
    $sql = "INSERT INTO radcheck (username, attribute, op, value) VALUES (?, 'Auth-Type', ':=', 'Accept')";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $voucher_code);
    $stmt->execute();

    $sql = "INSERT INTO radusergroup (username, groupname, priority) VALUES (?, ?, 1)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $voucher_code, $plan['planName']);
    $stmt->execute();

    // Masukkan data ke userinfo dan userbillinfo
    $creationby = $telegram_username . '@Radiusbot';
    $creation_date = date('Y-m-d H:i:s');
    $sql = "INSERT INTO userinfo (username, creationdate, creationby) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $voucher_code, $creation_date, $creationby);
    $stmt->execute();

    $sql = "INSERT INTO userbillinfo (username, planName, paymentmethod, cash, creationdate, creationby) VALUES (?, ?, 'cash', ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssss", $voucher_code, $plan['planName'], $plan['planCost'], $creation_date, $creationby);
    $stmt->execute();

    // Kirim voucher ke pengguna
    $login_url = "http://10.10.10.1:3990/login?username={$voucher_code}&password=Accept";
    $keyboard = [[['text' => "Login", 'url' => $login_url]]];
    $reply_markup = json_encode(['inline_keyboard' => $keyboard]);

    sendMessage($chat_id, "Voucher anda telah dibuat dengan kode: $voucher_code\nSisa saldo Anda sekarang: $new_balance", $bot_token, $reply_markup);

    // Kirim notifikasi ke admin
    $admin_message = "Pengguna dengan username Telegram @$telegram_username telah berhasil membeli voucher {$plan['planName']}.\nKode voucher: $voucher_code\nSisa saldo: $new_balance";
    sendMessage(ADMIN_ID, $admin_message, $bot_token);

    $stmt->close();
    $conn->close();
}

// Fungsi untuk menangani callback pembatalan pembelian
function beli_cancel_callback($callback_query, $bot_token) {
    $chat_id = $callback_query['message']['chat']['id'];
    sendMessage($chat_id, "Pembelian dibatalkan. Silakan pilih paket lain.", $bot_token);
}
