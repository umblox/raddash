// beli.php

// Konfigurasi Database dan Telegram Bot
$host = '127.0.0.1';
$dbname = 'radius';
$user = 'radius';
$pass = 'radius';
$adminId = '2123457759';
$botToken = '7530717438:AAFDpkb15BzqvjJx8-jNDT-Kg6JS0uhgbuo';

// Koneksi Database
$mysqli = new mysqli($host, $user, $pass, $dbname);
if ($mysqli->connect_error) {
    error_log("Koneksi database gagal: " . $mysqli->connect_error);
    exit;
}

// Kelas untuk Telegram Bot (sama dengan di /topup)
class TelegramBot {
    private $token;

    public function __construct($token) {
        $this->token = $token;
    }

    private function request($method, $data) {
        $url = "https://api.telegram.org/bot{$this->token}/{$method}";
        $options = [
            'http' => [
                'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
                'method'  => 'POST',
                'content' => http_build_query($data),
            ],
        ];
        $context  = stream_context_create($options);
        return file_get_contents($url, false, $context);
    }

    public function sendMessage($chat_id, $text, $options = []) {
        $data = array_merge(['chat_id' => $chat_id, 'text' => $text], $options);
        return $this->request('sendMessage', $data);
    }

    public function editMessageText($chat_id, $message_id, $text) {
        $data = [
            'chat_id' => $chat_id,
            'message_id' => $message_id,
            'text' => $text
        ];
        return $this->request('editMessageText', $data);
    }

    public function answerCallbackQuery($callback_query_id, $text = "") {
        $data = ['callback_query_id' => $callback_query_id, 'text' => $text];
        return $this->request('answerCallbackQuery', $data);
    }
}

$bot = new TelegramBot($botToken);

// Mengambil data dari Telegram
$update = json_decode(file_get_contents('php://input'), true);
if (isset($update['message'])) {
    $chat_id = $update['message']['chat']['id'];
    $telegram_id = $update['message']['from']['id'];
    $telegram_username = $update['message']['from']['username'] ?? null;

    if (!$telegram_username) {
        $bot->sendMessage($chat_id, "Anda harus memiliki username Telegram untuk membeli voucher.");
        exit;
    }

    if ($update['message']['text'] === '/beli') {
        handleBeli($chat_id, $telegram_id, $telegram_username);
    }
} elseif (isset($update['callback_query'])) {
    handleBeliCallback($update['callback_query']);
}

function handleBeli($chat_id, $telegram_id, $telegram_username) {
    global $mysqli, $bot;

    error_log("Menerima permintaan /beli dari pengguna $telegram_id ($telegram_username)");

    // Mengambil daftar paket dari database
    $result = $mysqli->query("SELECT id, plan_name, price FROM billing_plans");
    if ($result->num_rows > 0) {
        $keyboard = [];
        while ($row = $result->fetch_assoc()) {
            $plan_name = $row['plan_name'];
            $price = $row['price'];
            $plan_id = $row['id'];
            $keyboard[] = [['text' => "$plan_name - $price kredit", 'callback_data' => "beli,$plan_id"]];
        }

        $reply_markup = json_encode([
            'inline_keyboard' => $keyboard
        ]);
        $bot->sendMessage($chat_id, "Pilih paket yang ingin dibeli:", ['reply_markup' => $reply_markup]);
    } else {
        $bot->sendMessage($chat_id, "Tidak ada paket yang tersedia saat ini.");
    }
}

function handleBeliCallback($callback_query) {
    global $mysqli, $bot, $adminId;

    $data = $callback_query['data'];
    $chat_id = $callback_query['message']['chat']['id'];
    $message_id = $callback_query['message']['message_id'];
    $telegram_id = $callback_query['from']['id'];
    $telegram_username = $callback_query['from']['username'] ?? null;

    if (!$telegram_username) {
        $bot->editMessageText($chat_id, $message_id, "Anda harus memiliki username Telegram untuk membeli voucher.");
        return;
    }

    list(, $plan_id) = explode(",", $data);

    // Ambil detail paket dari database
    $stmt = $mysqli->prepare("SELECT plan_name, price FROM billing_plans WHERE id = ?");
    $stmt->bind_param("i", $plan_id);
    $stmt->execute();
    $stmt->bind_result($plan_name, $price);
    $stmt->fetch();
    $stmt->close();

    if (!$plan_name || !$price) {
        $bot->editMessageText($chat_id, $message_id, "Paket tidak ditemukan.");
        return;
    }

    error_log("Pengguna $telegram_id ($telegram_username) memilih paket $plan_name sebesar $price kredit");

    // Cek saldo pengguna
    $stmt = $mysqli->prepare("SELECT balance FROM users WHERE telegram_id = ?");
    $stmt->bind_param("i", $telegram_id);
    $stmt->execute();
    $stmt->bind_result($balance);
    $stmt->fetch();
    $stmt->close();

    if ($balance < $price) {
        $bot->editMessageText($chat_id, $message_id, "Saldo Anda tidak mencukupi untuk membeli paket ini. Silakan top-up terlebih dahulu.");
        return;
    }

    // Kurangi saldo pengguna
    $new_balance = $balance - $price;
    $stmt = $mysqli->prepare("UPDATE users SET balance = ? WHERE telegram_id = ?");
    $stmt->bind_param("ii", $new_balance, $telegram_id);
    $stmt->execute();
    $stmt->close();

    // Tambahkan pembelian ke tabel transaksi/voucher
    $stmt = $mysqli->prepare("INSERT INTO voucher_purchases (user_id, plan_id, status) VALUES (?, ?, 'active')");
    $stmt->bind_param("ii", $telegram_id, $plan_id);
    $stmt->execute();
    $stmt->close();

    // Beri tahu admin
    $admin_message = "Pembelian voucher baru:\n\nTelegram ID: $telegram_id\nUsername: @$telegram_username\nPaket: $plan_name\nHarga: $price kredit\n\n";
    $bot->sendMessage($adminId, $admin_message);

    // Beritahu pengguna bahwa pembelian sukses
    $bot->editMessageText($chat_id, $message_id, "Pembelian berhasil! Paket $plan_name telah ditambahkan ke akun Anda.\nSaldo baru Anda: $new_balance kredit.");
}
?>
