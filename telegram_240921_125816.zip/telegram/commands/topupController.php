<?php
// topup.php

// Konfigurasi Database dan Telegram Bot
$host = '127.0.0.1';
$dbname = 'radius';
$user = 'radius';
$pass = 'radius';
$adminId = '2123457759';
$botToken = '7530717438:AAFDpkb15BzqvjJx8-jNDT-Kg6JS0uhgbuo';

// Koneksi Database
$mysqli = new mysqli($host, $user, $pass, $dbname);
if ($mysqli->connect_error) {
    error_log("Koneksi database gagal: " . $mysqli->connect_error);
    exit;
}

// Fungsi untuk menangani perintah /topup
function handleTopupCommand($chat_id, $message) {
    global $connection;

    // Cek apakah ada permintaan top-up yang masih pending untuk user ini
    $stmt = $connection->prepare("SELECT id FROM topup_requests WHERE telegram_id = ? AND status = 'pending'");
    $stmt->bind_param("i", $chat_id);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // Jika ada permintaan pending, user tidak bisa melakukan topup lagi
        sendMessage($chat_id, "Anda sudah memiliki permintaan top-up yang sedang menunggu konfirmasi. Silakan tunggu.");
    } else {
        // Tampilkan pilihan nominal top-up
        $keyboard = array(
            array(
                array('text' => 'Rp 10.000', 'callback_data' => 'topup_10000'),
                array('text' => 'Rp 20.000', 'callback_data' => 'topup_20000')
            ),
            array(
                array('text' => 'Rp 50.000', 'callback_data' => 'topup_50000'),
                array('text' => 'Rp 100.000', 'callback_data' => 'topup_100000')
            )
        );

        // Inline keyboard
        $reply_markup = array(
            'inline_keyboard' => $keyboard
        );

        sendMessage($chat_id, "Pilih nominal top-up yang ingin Anda isi:", $reply_markup);
    }

    $stmt->close();
}

// Fungsi untuk menangani callback query (inline keyboard) top-up
function handleCallbackQuery($callback_query) {
    global $connection;

    $callback_data = $callback_query['data'];
    $chat_id = $callback_query['message']['chat']['id'];
    $message_id = $callback_query['message']['message_id'];

    if (strpos($callback_data, 'topup_') === 0) {
        // Ambil nominal topup
        $amount = str_replace('topup_', '', $callback_data);

        // Konfirmasi nominal
        $keyboard = array(
            array(
                array('text' => 'Benar', 'callback_data' => 'confirm_topup_' . $amount),
                array('text' => 'Salah', 'callback_data' => 'cancel_topup')
            )
        );

        $reply_markup = array(
            'inline_keyboard' => $keyboard
        );

        sendMessage($chat_id, "Apakah Anda yakin ingin melakukan top-up sebesar Rp " . $amount . "?", $reply_markup);
    } elseif (strpos($callback_data, 'confirm_topup_') === 0) {
        // Konfirmasi top-up oleh user
        $amount = str_replace('confirm_topup_', '', $callback_data);

        // Simpan permintaan top-up ke database dengan status pending
        $stmt = $connection->prepare("INSERT INTO topup_requests (telegram_id, amount, status) VALUES (?, ?, 'pending')");
        $stmt->bind_param("ii", $chat_id, $amount);
        $stmt->execute();
        $stmt->close();

        sendMessage($chat_id, "Permintaan top-up sebesar Rp $amount telah diterima dan menunggu konfirmasi admin.");

        // Kirim notifikasi ke admin
        $admin_chat_id = ADMIN_CHAT_ID;
        $keyboard = array(
            array(
                array('text' => 'Konfirmasi', 'callback_data' => 'approve_topup_' . $chat_id . '_' . $amount),
                array('text' => 'Tolak', 'callback_data' => 'reject_topup_' . $chat_id)
            )
        );

        $reply_markup = array(
            'inline_keyboard' => $keyboard
        );

        sendMessage($admin_chat_id, "Ada permintaan top-up sebesar Rp $amount dari user ID: $chat_id. Konfirmasi?", $reply_markup);

    } elseif ($callback_data == 'cancel_topup') {
        sendMessage($chat_id, "Permintaan top-up dibatalkan.");
    } elseif (strpos($callback_data, 'approve_topup_') === 0) {
        // Admin mengonfirmasi top-up
        list(, $user_chat_id, $amount) = explode('_', $callback_data);

        // Tambahkan saldo user
        $stmt = $connection->prepare("UPDATE users SET balance = balance + ? WHERE telegram_id = ?");
        $stmt->bind_param("ii", $amount, $user_chat_id);
        $stmt->execute();
        $stmt->close();

        // Ubah status permintaan top-up menjadi confirmed
        $stmt = $connection->prepare("UPDATE topup_requests SET status = 'confirmed' WHERE telegram_id = ? AND status = 'pending'");
        $stmt->bind_param("i", $user_chat_id);
        $stmt->execute();
        $stmt->close();

        sendMessage($admin_chat_id, "Top-up sebesar Rp $amount telah dikonfirmasi untuk user ID: $user_chat_id.");
        sendMessage($user_chat_id, "Top-up sebesar Rp $amount telah dikonfirmasi oleh admin. Saldo Anda telah bertambah.");

    } elseif (strpos($callback_data, 'reject_topup_') === 0) {
        // Admin menolak top-up
        $user_chat_id = str_replace('reject_topup_', '', $callback_data);

        // Ubah status permintaan top-up menjadi rejected
        $stmt = $connection->prepare("UPDATE topup_requests SET status = 'rejected' WHERE telegram_id = ? AND status = 'pending'");
        $stmt->bind_param("i", $user_chat_id);
        $stmt->execute();
        $stmt->close();

        sendMessage($admin_chat_id, "Permintaan top-up user ID: $user_chat_id telah ditolak.");
        sendMessage($user_chat_id, "Permintaan top-up Anda ditolak oleh admin. Saldo Anda tidak bertambah.");
    }
}

// Fungsi untuk mengirim pesan ke user atau admin
function sendMessage($chat_id, $text, $reply_markup = null) {
    $url = "https://api.telegram.org/bot" . BOT_TOKEN . "/sendMessage";
    $post_fields = array(
        'chat_id' => $chat_id,
        'text' => $text,
        'parse_mode' => 'HTML'
    );

    if ($reply_markup) {
        $post_fields['reply_markup'] = json_encode($reply_markup);
    }

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_fields);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $result = curl_exec($ch);
    curl_close($ch);

    return $result;
}
