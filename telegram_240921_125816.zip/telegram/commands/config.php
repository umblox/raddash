<?php

// Global configuration
define('BOT_TOKEN', '7530717438:AAFDpkb15BzqvjJx8-jNDT-Kg6JS0uhgbuo');
define('ADMIN_ID', '2123457759');

function getDbConnection() {
    $host = '127.0.0.1';  // Ganti dengan host Anda
    $db = 'radius'; // Nama database Anda
    $user = 'radius';        // Nama pengguna database Anda
    $pass = 'radius';        // Kata sandi pengguna database Anda

    $conn = new mysqli($host, $user, $pass, $db);
    if ($conn->connect_error) {
        die("Koneksi database gagal: " . $conn->connect_error);
    }
    return $conn;
}

function getVoucherPrefix($planName) {
    // Array prefix voucher berdasarkan nama plan
    $VOUCHER_PREFIX = [
        '1Hari' => '3k',
        '5k' => '5k',
        '7Hari' => '15k',
        '30Hari' => '60k'
    ];

    // Jika planName ditemukan, return prefix-nya; jika tidak, return default prefix
    return isset($VOUCHER_PREFIX[$planName]) ? $VOUCHER_PREFIX[$planName] : 'edit_di_config/prefix';
}
?>
