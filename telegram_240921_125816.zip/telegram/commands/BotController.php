<?php

class BotController
{
    private $apiUrl;

    public function __construct()
    {
        $this->apiUrl = "https://api.telegram.org/bot" . BOT_TOKEN;
    }

    // Fungsi untuk mengirim pesan
    public function sendMessage($chat_id, $text, $options = [])
    {
        $data = [
            'chat_id' => $chat_id,
            'text' => $text,
            'parse_mode' => 'HTML',
        ];

        if (!empty($options)) {
            $data['reply_markup'] = json_encode($options);
        }

        $this->sendRequest("sendMessage", $data);
    }

    // Fungsi untuk mengirim request ke Telegram API
    private function sendRequest($method, $data)
    {
        $url = $this->apiUrl . "/" . $method;

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        $result = curl_exec($ch);
        curl_close($ch);

        return $result;
    }
}
?>
