<?php
// saldo.php

// Konfigurasi Database dan Telegram Bot
$host = '127.0.0.1';
$dbname = 'radius';
$user = 'radius';
$pass = 'radius';
$adminId = '2123457759';
$botToken = '7530717438:AAFDpkb15BzqvjJx8-jNDT-Kg6JS0uhgbuo';

// Koneksi Database
$mysqli = new mysqli($host, $user, $pass, $dbname);
if ($mysqli->connect_error) {
    error_log("Koneksi database gagal: " . $mysqli->connect_error);
    exit;
}

// Kelas untuk Telegram Bot
class saldoController {
    private $token;

    public function __construct($token) {
        $this->token = $token;
    }

    private function request($method, $data) {
        $url = "https://api.telegram.org/bot{$this->token}/{$method}";
        $options = [
            'http' => [
                'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
                'method'  => 'POST',
                'content' => http_build_query($data),
            ],
        ];
        $context  = stream_context_create($options);
        return file_get_contents($url, false, $context);
    }

    public function sendMessage($chat_id, $text) {
        $data = ['chat_id' => $chat_id, 'text' => $text];
        return $this->request('sendMessage', $data);
    }
}

$bot = new TelegramBot($botToken);

// Mengambil data dari Telegram
$update = json_decode(file_get_contents('php://input'), true);

if (isset($update['message'])) {
    $chat_id = $update['message']['chat']['id'];
    $telegram_id = $update['message']['from']['id'];

    error_log("Menerima perintah /saldo dari pengguna $telegram_id");

    $stmt = $mysqli->prepare("SELECT balance FROM users WHERE telegram_id = ?");
    $stmt->bind_param("i", $telegram_id);
    $stmt->execute();
    $stmt->bind_result($balance);
    $stmt->fetch();
    $stmt->close();

    if ($balance !== null) {
        $bot->sendMessage($chat_id, sprintf("Saldo Anda adalah %.2f kredit.", $balance));
    } else {
        $bot->sendMessage($chat_id, "Pengguna tidak ditemukan dalam sistem.");
    }
}

$mysqli->close();
?>
