<?php
function status($chat_id, $user_id) {
    $message = "Selamat datang! Pilih perintah dari menu.";
    sendMessage($chat_id, $message);
}
?>
